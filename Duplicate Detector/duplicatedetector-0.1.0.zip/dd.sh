#!/bin/bash
java -cp duplicatedetector-0.1.0.jar:miglayout-3.7.2-swing.jar com.googlecode.duplicatedetector.Main
