#!/bin/bash
java -cp duplicatedetector-0.0.1.jar com.googlecode.duplicatedetector.Main
