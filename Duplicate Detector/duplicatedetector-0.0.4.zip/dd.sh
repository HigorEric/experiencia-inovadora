#!/bin/bash
java -cp duplicatedetector-0.0.4.jar:miglayout-3.7.2-swing.jar com.googlecode.duplicatedetector.Main
